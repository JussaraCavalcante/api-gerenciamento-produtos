# API Gerenciamento de Produtos e Categorias

API REST desenvolvida com Java e Spring Boot. Utiliza banco de dados em memória (H2).

## Executando o Projeto

```bash
./mvnw spring-boot:run
```

- Console H2: http://localhost:8080/h2-console
  - JDBC URL: `jdbc:h2:mem:testdb`
  - User: `sa`

## Endpoints

### Categorias
- `POST /categorias`
- `GET /categorias`
- `GET /categorias/{id}`
- `PUT /categorias/{id}`
- `DELETE /categorias/{id}`

### Produtos
- `POST /produtos/categoria/{categoriaId}`
- `GET /produtos`
- `GET /produtos/{id}`
- `PUT /produtos/{id}`
- `DELETE /produtos/{id}`
- `GET /produtos/categoria/{categoriaId}`