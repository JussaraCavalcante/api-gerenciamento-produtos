package com.fiesc.api.services;

import com.fiesc.api.entities.Produto;
import com.fiesc.api.entities.Categoria;
import com.fiesc.api.repositories.ProdutoRepository;
import com.fiesc.api.repositories.CategoriaRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class ProdutoService {
    private final ProdutoRepository produtoRepo;
    private final CategoriaRepository categoriaRepo;

    public ProdutoService(ProdutoRepository produtoRepo, CategoriaRepository categoriaRepo) {
        this.produtoRepo = produtoRepo;
        this.categoriaRepo = categoriaRepo;
    }

    public Produto criar(Produto produto, Long categoriaId) {
        Categoria categoria = categoriaRepo.findById(categoriaId).orElseThrow();
        produto.setCategoria(categoria);
        produto.setDataCadastro(LocalDate.now());
        return produtoRepo.save(produto);
    }

    public List<Produto> listar() {
        return produtoRepo.findAll();
    }

    public Optional<Produto> buscarPorId(Long id) {
        return produtoRepo.findById(id);
    }

    public Produto atualizar(Long id, Produto novoProduto) {
        Produto existente = produtoRepo.findById(id).orElseThrow();
        existente.setNome(novoProduto.getNome());
        existente.setDescricao(novoProduto.getDescricao());
        existente.setPreco(novoProduto.getPreco());
        return produtoRepo.save(existente);
    }

    public void excluir(Long id) {
        produtoRepo.deleteById(id);
    }

    public List<Produto> listarPorCategoria(Long categoriaId) {
        return produtoRepo.findByCategoriaId(categoriaId);
    }
}